colorway1 = ['#330974f1', '#339fccfa']
colorway1_serious = [ '#9fccfa','#0974f1']
colorway2 = ['#ea5753', '#ffb88e']
colorway_colorway = '#0974f1'
switch_colorway = '#b9dcf2'
background_colorway = '#243748'
trythis = '#9fccfa'
## Icons 
home_icon = 'https://img.icons8.com/?size=100&id=41651&format=png&color=000000'
clock_icon = 'https://img.icons8.com/?size=100&id=49923&format=png&color=000000'
classes_icon = 'https://img.icons8.com/?size=100&id=43215&format=png&color=000000'
logo_icon = 'https://img.icons8.com/?size=100&id=38729&format=png&color=FFFFFF' 
nigeria_icon = 'https://img.icons8.com/?size=100&id=0Xk54eqHLmSG&format=png&color=000000'
big_clock_icon = 'https://img.icons8.com/?size=100&id=42258&format=png&color=000000'
power_icon = 'https://img.icons8.com/?size=100&id=51018&format=png&color=000000'