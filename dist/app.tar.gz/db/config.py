firebaseConfig = {
  'apiKey': "AIzaSyAiCYRgasuxn_f-nVU4Qf1co9PfpE9MGJY",
  'authDomain': "clockinapp-2fb97.firebaseapp.com",
  'projectId': "clockinapp-2fb97",
  'storageBucket': "clockinapp-2fb97.appspot.com",
  'messagingSenderId': "622735093703",
  'appId': "1:622735093703:web:5685813d0a70a84bfaf3e2",
  'measurementId': "G-KD2PEJHVK9", 
  'databaseURL': 'https://clockinapp-2fb97-default-rtdb.europe-west1.firebasedatabase.app/'
}