from flet import * 

class TodayClasses(UserControl):
    pass